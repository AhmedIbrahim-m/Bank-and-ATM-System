#pragma once
#include "/home/ww816613abdo/clsDate.h"
#include "/home/ww816613abdo/clsPerson.h"
#include "/home/ww816613abdo/clsString.h"
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class clsBankUsers : public clsPerson {

private:
  string _UserName;
  string _Password;
  short _Permission;
  bool _MarkeForDelete = false;

  enum enMode { EmptyMode = 0, UpdateMode = 1, AddNewMode = 2 };

  enMode _Mode;

  static clsBankUsers _ConvertLineToObjectUser(string Line,
                                               string sepretor = "#//#") {

    vector<string> DataUser;

    DataUser = clsString::Split(Line, sepretor);

    return clsBankUsers(enMode::UpdateMode, DataUser[0], DataUser[1],
                        DataUser[2], DataUser[3], DataUser[4], DataUser[5],
                        stoi(DataUser[6]));
  }

  static string _ConvertUserObjectToLine(clsBankUsers User,
                                         string Seperator = "#//#") {

    string UserRecord = "";
    UserRecord += User._FirstName + Seperator;
    UserRecord += User._LastName + Seperator;
    UserRecord += User._Email + Seperator;
    UserRecord += User._Phone + Seperator;
    UserRecord += User._UserName + Seperator;
    UserRecord += User._Password + Seperator;
    UserRecord += to_string(User._Permission);

    return UserRecord;
  }

  string _ConvertUserToLine(string Seperator = "#//#") {

    string UserRecord = "";
    UserRecord += clsDate::PrintDateNow() + " - ";
    UserRecord += clsDate::GetSystemTime() + Seperator;
    UserRecord += _UserName + Seperator;
    UserRecord += _Password + Seperator;
    UserRecord += to_string(_Permission);

    return UserRecord;
  }

  static vector<clsBankUsers> _LoadUsersDataFromFile() {

    fstream NewFile;

    vector<clsBankUsers> Users;
    NewFile.open("/home/ww816613abdo/Users.txt", ios::in);

    string Line;

    while (getline(NewFile, Line)) {

      if (NewFile.is_open()) {

        clsBankUsers UserName = _ConvertLineToObjectUser(Line);
        Users.push_back(UserName);
      }
    }

    NewFile.close();

    return Users;
  }

  void _Update() {

    vector<clsBankUsers> Users;
    Users = _LoadUsersDataFromFile();

    for (clsBankUsers &C : Users) {

      if (C._UserName == _UserName) {

        C = *this;
        break;
      }
    }

    _SaveUsersDataToFile(Users);
  }

  void _SaveUsersDataToFile(vector<clsBankUsers> Users) {

    fstream MyFile;

    MyFile.open("/home/ww816613abdo/Users.txt", ios::out);

    string Line = "";
    for (clsBankUsers &C : Users) {

      if (C._MarkeForDelete == false) {
        Line = _ConvertUserObjectToLine(C);
        MyFile << Line << endl;
      }
    }

    MyFile.close();
  }

  void _AddDataLineToFile(string Line, string FileName) {

    fstream MyFile;

    MyFile.open(FileName, ios::app);

    if (MyFile.is_open()) {

      MyFile << Line << endl;
    }

    MyFile.close();
  }

  void _AddNew() {
    _AddDataLineToFile(_ConvertUserObjectToLine(*this),
                       "/home/ww816613abdo/Users.txt");
  }

  static clsBankUsers _GetEmptyUserObject() {

    return clsBankUsers(EmptyMode, "", "", "", "", "", "", 0);
  }

public:
  clsBankUsers(enMode Mode, string FirstName, string LastName, string Email,
               string Phone, string UserName, string Password, int Permissions)
      : clsPerson(0, FirstName, LastName, Email, Phone)

  {
    _Mode = Mode;
    _UserName = UserName;
    _Password = Password;
    _Permission = Permissions;
  }

  enum enPermissions {
    eAll = -1,
    pListClients = 1,
    pAddNewClient = 2,
    pDeleteClient = 4,
    pUpdateClients = 8,
    pFindClient = 16,
    pTranactions = 32,
    pManageUsers = 64
  };

  enum enSaveResults {
    svFaildEmptyObject = 0,
    svSucceeded = 1,
    svFaildUserNameExists = 2
  };

  static clsBankUsers Find(string UserName) {

    fstream MyFile;

    MyFile.open("/home/ww816613abdo/Users.txt", ios::in);

    if (MyFile.is_open()) {

      string Line = "";

      while (getline(MyFile, Line)) {

        clsBankUsers Client = _ConvertLineToObjectUser(Line);

        if (Client._UserName == UserName) {

          MyFile.close();
          return Client;
        }
      }
    }
    return _GetEmptyUserObject();
  }

  static clsBankUsers Find(string UserName, string PassWord) {

    fstream MyFile;

    MyFile.open("/home/ww816613abdo/Users.txt", ios::in);

    if (MyFile.is_open()) {

      string Line = "";

      while (getline(MyFile, Line)) {

        clsBankUsers Client = _ConvertLineToObjectUser(Line);

        if (Client._UserName == UserName && Client._Password == PassWord) {

          MyFile.close();
          return Client;
        }
      }
    }

    return _GetEmptyUserObject();
  }

  static clsBankUsers GetAddNewUserObject(string UserName) {

    return clsBankUsers(enMode::AddNewMode, "", "", "", "", UserName, "", 0);
  }

  bool Delete() {

    vector<clsBankUsers> Users;
    Users = _LoadUsersDataFromFile();

    for (clsBankUsers &C : Users) {

      if (C._UserName == _UserName) {

        C._MarkeForDelete = true;
        break;
      }
    }

    _SaveUsersDataToFile(Users);

    *this = _GetEmptyUserObject();

    return true;
  }

  static vector<clsBankUsers> GetUsersList() {
    return _LoadUsersDataFromFile();
  }

  bool IsEmpty() { return (_Mode == EmptyMode); }

  static bool IsUserExist(string UserName) {

    clsBankUsers User1 = clsBankUsers::Find(UserName);

    return (!User1.IsEmpty());
  }

  enSaveResults Save() {

    switch (_Mode) {

    case enMode::EmptyMode: {
      return enSaveResults::svFaildEmptyObject;
    }
    case enMode::UpdateMode: {
      _Update();
      return enSaveResults::svSucceeded;
    }

    case enMode::AddNewMode: {

      if (IsUserExist(_UserName)) {

        return enSaveResults::svFaildUserNameExists;

      } else {

        _AddNew();

        _Mode = enMode::UpdateMode;
        return enSaveResults::svSucceeded;
      }
    }
    }
  }

  bool MarkedForDeleted() { return _MarkeForDelete; }

  string GetUserName() { return _UserName; }

  void SetUserName(string UserName) { _UserName = UserName; }

  void SetPermissions(int Permission) { _Permission = Permission; }

  int GetPermissions() { return _Permission; }

  void SetPassword(string Password) { _Password = Password; }

  string GetPassword() { return _Password; }

  bool CheckAccessPermission(enPermissions Permission) {
    if (this->_Permission == enPermissions::eAll)
      return true;

    if ((Permission & this->_Permission) == Permission)
      return true;
    else
      return false;
  }

  void AddRegisterUser() {

    _AddDataLineToFile(_ConvertUserToLine(),
                       "/home/ww816613abdo/LoginRegister.txt");
  };
};