#pragma once
#include "/home/ww816613abdo/clsPerson.h"
#include "/home/ww816613abdo/clsString.h"
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
class clsBankClient : public clsPerson {

protected:
  string _AccountNumber;
  string _PinCode;
  float _AccountBalance;
  bool _MarkForDelete = false;

  enum enMode { EmptyMode = 0, UpdateMode = 1, AddNewMode = 2 };
  enMode _Mode;

  static clsBankClient _ConvertLinetoClientObject(string Line,
                                                  string Seprator = "#//#") {

    vector<string> vClientData;

    vClientData = clsString::Split(Line, Seprator);

    return clsBankClient(UpdateMode, vClientData[0], vClientData[1],
                         vClientData[2], vClientData[3], vClientData[4],
                         vClientData[5], stod(vClientData[6]));
  }

  static string _ConverClientObjectToLine(clsBankClient Client,
                                          string Seperator = "#//#") {

    string stClientRecord = "";
    stClientRecord += Client._FirstName + Seperator;
    stClientRecord += Client._LastName + Seperator;
    stClientRecord += Client._Email + Seperator;
    stClientRecord += Client._Phone + Seperator;
    stClientRecord += Client._AccountNumber + Seperator;
    stClientRecord += Client._PinCode + Seperator;
    stClientRecord += to_string(Client._AccountBalance);

    return stClientRecord;
  }
  static clsBankClient _GetEmptyClientObject() {

    return clsBankClient(EmptyMode, "", "", "", "", "", "", 0);
  }

  static vector<clsBankClient> _LoadClientsDataFromFile() {

    fstream MyFile;

    vector<clsBankClient> Clients;

    MyFile.open("/home/ww816613abdo/Clients.txt", ios::in);

    if (MyFile.is_open()) {

      string Line = "";

      while (getline(MyFile, Line)) {

        clsBankClient Client = _ConvertLinetoClientObject(Line);

        Clients.push_back(Client);
      }

      MyFile.close();
    }

    return Clients;
  }

  void _Update() {

    vector<clsBankClient> Clients;
    Clients = _LoadClientsDataFromFile();

    for (clsBankClient &C : Clients) {

      if (C._AccountNumber == _AccountNumber) {

        C = *this;
        break;
      }
    }

    _SaveClientsDataToFile(Clients);
  }

  void _SaveClientsDataToFile(vector<clsBankClient> Clients) {

    fstream MyFile;

    MyFile.open("/home/ww816613abdo/Clients.txt", ios::out);

    string Line = "";
    for (clsBankClient &C : Clients) {

      if (C._MarkForDelete == false) {
        Line = _ConverClientObjectToLine(C);
        MyFile << Line << endl;
      }
    }

    MyFile.close();
  }

  void _AddDataLineToFile(string Line) {

    fstream MyFile;

    MyFile.open("/home/ww816613abdo/Clients.txt", ios::app);

    if (MyFile.is_open()) {

      MyFile << Line << endl;
    }

    MyFile.close();
  }

  void _AddNew() { _AddDataLineToFile(_ConverClientObjectToLine(*this)); }

public:
  clsBankClient(enMode Mode, string FirstName, string LastName, string Email,
                string Phone, string AccountNumber, string PinCode,
                float AccountBalance)
      : clsPerson(0, FirstName, LastName, Email, Phone) {

    _Mode = Mode;
    _AccountNumber = AccountNumber;
    _PinCode = PinCode;
    _AccountBalance = AccountBalance;
  };

  string AccountNumber() { return _AccountNumber; }

  void SetPinCode(string PinCode) { _PinCode = PinCode; }

  string GetPinCode() { return _PinCode; }

  void SetAccountBalance(float AccountBalance) {

    _AccountBalance = AccountBalance;
  }

  float GetAccountBalance() { return _AccountBalance; }

  void Print() {
    cout << "\nClient Card:";
    cout << "\n___________________";
    cout << "\nFirstName   : " << _FirstName;
    cout << "\nLastName    : " << _LastName;
    cout << "\nFull Name   : " << FullName();
    cout << "\nEmail       : " << _Email;
    cout << "\nPhone       : " << _Phone;
    cout << "\nAcc. Number : " << _AccountNumber;
    cout << "\nPassword    : " << _PinCode;
    cout << "\nBalance     : " << _AccountBalance;
    cout << "\n___________________\n";
  }

  static clsBankClient Find(string AccountNumber) {

    fstream MyFile;

    MyFile.open("/home/ww816613abdo/Clients.txt", ios::in);

    if (MyFile.is_open()) {

      string Line = "";

      while (getline(MyFile, Line)) {

        clsBankClient Client = _ConvertLinetoClientObject(Line);

        if (Client._AccountNumber == AccountNumber) {

          MyFile.close();
          return Client;
        }
      }
    }
    return _GetEmptyClientObject();
  }

  static clsBankClient Find(string AccountNumber, string PinCode) {

    fstream MyFile;

    MyFile.open("/home/ww816613abdo/Clients.txt", ios::in);

    if (MyFile.is_open()) {

      string Line = "";

      while (getline(MyFile, Line)) {

        clsBankClient Client = _ConvertLinetoClientObject(Line);

        if (Client._AccountNumber == AccountNumber &&
            Client._PinCode == PinCode) {

          MyFile.close();
          return Client;
        }
      }
    }

    return _GetEmptyClientObject();
  }

  bool IsEmpty() { return (_Mode == EmptyMode); }

  static bool IsClientExist(string AccountNumber) {

    clsBankClient Client1 = clsBankClient::Find(AccountNumber);

    return (!Client1.IsEmpty());
  }

  enum enSaveResults {
    svFaildEmptyObject = 0,
    svSucceeded = 1,
    svFaildAccountNumberExists = 2
  };

  enSaveResults Save() {

    switch (_Mode) {

    case enMode::EmptyMode: {
      return enSaveResults::svFaildEmptyObject;
    }
    case enMode::UpdateMode: {
      _Update();
      return enSaveResults::svSucceeded;
    }

    case enMode::AddNewMode: {

      if (IsClientExist(_AccountNumber)) {

        return enSaveResults::svFaildAccountNumberExists;

      } else {

        _AddNew();

        _Mode = enMode::UpdateMode;
        return enSaveResults::svSucceeded;
      }
    }
    }
  }

  static clsBankClient GetAddNewClientObject(string AccountNumber) {

    return clsBankClient(enMode::AddNewMode, "", "", "", "", AccountNumber, "",
                         0);
  }

  bool Delete() {

    vector<clsBankClient> Clients;
    Clients = _LoadClientsDataFromFile();

    for (clsBankClient &C : Clients) {

      if (C._AccountNumber == _AccountNumber) {

        C._MarkForDelete = true;
        break;
      }
    }

    _SaveClientsDataToFile(Clients);

    *this = _GetEmptyClientObject();

    return true;
  }

  static vector<clsBankClient> GetClientsList() {

    return _LoadClientsDataFromFile();
  }

  static void PrintClientRecordLine(clsBankClient Client) {

    cout << "| " << setw(15) << left << Client._AccountNumber;
    cout << "| " << setw(20) << left << Client.FullName();
    cout << "| " << setw(12) << left << Client._Phone;
    cout << "| " << setw(20) << left << Client._Email;
    cout << "| " << setw(10) << left << Client._PinCode;
    cout << "| " << setw(12) << left << Client._AccountBalance;
  }

  static float GetTotalBalances() {
    vector<clsBankClient> vClients = clsBankClient::GetClientsList();

    double TotalBalances = 0;

    for (clsBankClient Client : vClients) {

      TotalBalances += Client._AccountBalance;
    }

    return TotalBalances;
  }

  void Deposit(double Amount) {
    _AccountBalance += Amount;
    Save();
  }

  bool WithDraw(double Amount) {

    if (Amount > _AccountBalance) {

      return false;
    }

    _AccountBalance -= Amount;
    Save();
    return true;
  }
};
