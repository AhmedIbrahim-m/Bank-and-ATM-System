#pragma once

#include "/home/ww816613abdo/LogicBankPorject/clsBankUsers.h"
#include "/home/ww816613abdo/Ui/clsMainScreen.h"
#include "/home/ww816613abdo/Ui/clsScreen.h"
#include "Global.h"
#include <iomanip>
#include <iostream>
#include <string>

class clsLoginScreen : protected clsScreen {

private:
  static void _Login() {
    bool LoginFaild = false;
    short Times = 3;
    string Username, Password;
    do {

      if (Times == 0) {
        cout << "\033[2J\033[1;1H";
        cout << "you blocked try again later " << endl;
        return;
      }

      _DrawScreenHeader("\t  Login Screen");

      cout << "Enter Username? ";
      cin >> Username;

      cout << "Enter Password? ";
      cin >> Password;

      CurrentUser = clsBankUsers::Find(Username, Password);

      if ((LoginFaild=CurrentUser.IsEmpty())) {
        cout << "\033[2J\033[1;1H";
        --Times;
        cout << "\nInvlaid Username/Password!\n\n";
        cout << "you have " << Times << " times (s) for login" << endl;
        continue;
      }

      if (!(LoginFaild = CurrentUser.IsEmpty())) {
        CurrentUser.AddRegisterUser();
        clsMainScreen::ShowMainMenue();
        cout << "\033[2J\033[1;1H";
        LoginFaild = CurrentUser.IsEmpty();
        Times=3;
      }

    } while (LoginFaild);
  }

public:
  static void ShowLoginScreen() {
    system("cls");
    _Login();
  }
};
