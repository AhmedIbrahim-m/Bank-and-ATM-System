#pragma once
#include "/home/ww816613abdo/LogicBankPorject/clsBankUsers.h"

clsBankUsers CurrentUser =clsBankUsers::Find("","");
