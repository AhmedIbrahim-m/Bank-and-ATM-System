#pragma once
#include "/home/ww816613abdo/LogicBankPorject/clsBankUsers.h"
#include "/home/ww816613abdo/Ui/clsScreen.h"
#include "/home/ww816613abdo/clsInputValidate.h"
#include <iostream>

class clsFindUserScreen : protected clsScreen {

private:
  static void _PrintUser(clsBankUsers User) {
    cout << "\nUser Card:";
    cout << "\n___________________";
    cout << "\nFirstName   : " << User.FirstName();
    cout << "\nLastName    : " << User.LastName();
    cout << "\nFull Name   : " << User.FullName();
    cout << "\nEmail       : " << User.Email();
    cout << "\nPhone       : " << User.Phone();
    cout << "\nUserName    : " << User.GetUserName();
    cout << "\nPassword    : " << User.GetPassword();
    cout << "\nPermissions : " << User.GetPermissions();
    cout << "\n___________________\n";
  }

public:
  static void ShowFindUserScreen() {

    _DrawScreenHeader("\t  Find User Screen");

    string UserName;
    cout << "\nPlease Enter UserName: ";
    UserName = clsInputValidate::ReadString("");
    while (!clsBankUsers::IsUserExist(UserName)) {
      cout << "\nUser is not found, choose another one: ";
      UserName = clsInputValidate::ReadString("");
    }

    clsBankUsers User1 = clsBankUsers::Find(UserName);

    if (!User1.IsEmpty()) {
      cout << "\nUser Found :-)\n";
    } else {
      cout << "\nUser Was not Found :-(\n";
    }

    _PrintUser(User1);
  }
};
