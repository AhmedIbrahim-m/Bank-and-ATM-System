#pragma once
#include "/home/ww816613abdo/Ui/clsScreen.h"
#include <iostream>
//#include "clsPerson.h"
#include "/home/ww816613abdo/LogicBankPorject/clsBankUsers.h"
#include "/home/ww816613abdo/clsInputValidate.h"

class clsUpdateUserScreen : protected clsScreen

{
private:
  static void _ReadUserInfo(clsBankUsers &User) {
    cout << "\nEnter FirstName: ";
    User.setFirstName(clsInputValidate::ReadString(""));

    cout << "\nEnter LastName: ";
    User.setLastName(clsInputValidate::ReadString(""));

    cout << "\nEnter Email: ";
    User.setEmail(clsInputValidate::ReadString(""));

    cout << "\nEnter Phone: ";
    User.setPhone(clsInputValidate::ReadString(""));

    cout << "\nEnter Password: ";
    User.SetPassword( clsInputValidate::ReadString(""));

    cout << "\nEnter Permission: ";
    User.SetPermissions(_ReadPermissionsToSet());
  }

  static void _PrintUser(clsBankUsers User) {
    cout << "\nUser Card:";
    cout << "\n___________________";
    cout << "\nFirstName   : " << User.FirstName();
    cout << "\nLastName    : " << User.LastName();
    cout << "\nFull Name   : " << User.FullName();
    cout << "\nEmail       : " << User.Email();
    cout << "\nPhone       : " << User.Phone();
    cout << "\nUser Name   : " << User.GetUserName();
    cout << "\nPassword    : " << User.GetPassword();
    cout << "\nPermissions : " << User.GetPermissions();
    cout << "\n___________________\n";
  }

  static int _ReadPermissionsToSet() {

    int Permissions = 0;
    char Answer = 'n';

    cout << "\nDo you want to give full access? y/n? ";
    cin >> Answer;
    if (Answer == 'y' || Answer == 'Y') {
      return -1;
    }

    cout << "\nDo you want to give access to : \n ";

    cout << "\nShow Client List? y/n? ";
    cin >> Answer;
    if (Answer == 'y' || Answer == 'Y') {

      Permissions += clsBankUsers::enPermissions::pListClients;
    }

    cout << "\nAdd New Client? y/n? ";
    cin >> Answer;
    if (Answer == 'y' || Answer == 'Y') {
      Permissions += clsBankUsers::enPermissions::pAddNewClient;
    }

    cout << "\nDelete Client? y/n? ";
    cin >> Answer;
    if (Answer == 'y' || Answer == 'Y') {
      Permissions += clsBankUsers::enPermissions::pDeleteClient;
    }

    cout << "\nUpdate Client? y/n? ";
    cin >> Answer;
    if (Answer == 'y' || Answer == 'Y') {
      Permissions += clsBankUsers::enPermissions::pUpdateClients;
    }

    cout << "\nFind Client? y/n? ";
    cin >> Answer;
    if (Answer == 'y' || Answer == 'Y') {
      Permissions += clsBankUsers::enPermissions::pFindClient;
    }

    cout << "\nTransactions? y/n? ";
    cin >> Answer;
    if (Answer == 'y' || Answer == 'Y') {
      Permissions += clsBankUsers::enPermissions::pTranactions;
    }

    cout << "\nManage Users? y/n? ";
    cin >> Answer;
    if (Answer == 'y' || Answer == 'Y') {
      Permissions += clsBankUsers::enPermissions::pManageUsers;
    }

    return Permissions;
  }

public:
  static void ShowUpdateUserScreen() {

    _DrawScreenHeader("\tUpdate User Screen");

    string UserName = "";

    cout << "\nPlease Enter User UserName: ";
    UserName = clsInputValidate::ReadString("");

    while (!clsBankUsers::IsUserExist(UserName)) {
      cout << "\nAccount number is not found, choose another one: ";
      UserName = clsInputValidate::ReadString("");
    }

    clsBankUsers User1 = clsBankUsers::Find(UserName);

    _PrintUser(User1);

    cout << "\nAre you sure you want to update this User y/n? ";

    char Answer = 'n';
    cin >> Answer;

    if (Answer == 'y' || Answer == 'Y') {

      cout << "\n\nUpdate User Info:";
      cout << "\n____________________\n";

      _ReadUserInfo(User1);

      clsBankUsers::enSaveResults SaveResult;

      SaveResult = User1.Save();

      switch (SaveResult) {
      case clsBankUsers::enSaveResults::svSucceeded: {
        cout << "\nUser Updated Successfully :-)\n";

        _PrintUser(User1);
        break;
      }
      case clsBankUsers::enSaveResults::svFaildEmptyObject: {
        cout << "\nError User was not saved because it's Empty";
        break;
      }
      }
    }
  }
};
