#pragma once
#include "/home/ww816613abdo/Ui/clsMainScreen.h"
#include "/home/ww816613abdo/Ui/clsScreen.h"
#include "/home/ww816613abdo/clsInputValidate.h"
#include "clsDepositScreen.h"
#include "clsTotalBalancesScreen.h"
#include "clsWithDrawScreen.h"
#include <iomanip>
#include <iostream>
using namespace std;

class clsTransactionMainScreen : clsScreen {

private:
  enum enTransactionsMenueOptions {
    eDeposit = 1,
    eWithdraw = 2,
    eShowTotalBalance = 3,
    eShowMainMenue = 4
  };

  static short ReadTransactionsMenueOption() {
    cout << setw(37) << left << ""
         << "Choose what do you want to do? [1 to 4]? ";
    short Choice = clsInputValidate::ReadIntNumberBetween(
        1, 4, "Enter Number between 1 to 4? ");
    return Choice;
  }

  static void _ShowDepositScreen() { clsDepositScreen::ShowDepositScreen(); }

  static void _ShowWithdrawScreen() { clsWithDrawScreen::ShowWithDrawScreen(); }

  static void _ShowTotalBalancesScreen() {
    clsTotalBalancesScreen::ShowTotalBalances();
  }

  static void _GoBackToTransactionsMenue() {
    cout << "\n\nPress any key to go back to Transactions Menue...";
    cin.ignore(); 
    cin.get();
    cout << "\033[2J\033[1;1H";
    ShowTransactionsMenue();
  }

  static void _PerformTransactionsMenueOption(
      enTransactionsMenueOptions TransactionsMenueOption) {
    switch (TransactionsMenueOption) {
    case enTransactionsMenueOptions::eDeposit: {

      _ShowDepositScreen();
      _GoBackToTransactionsMenue();
      break;
    }

    case enTransactionsMenueOptions::eWithdraw: {

      _ShowWithdrawScreen();
      _GoBackToTransactionsMenue();
      break;
    }

    case enTransactionsMenueOptions::eShowTotalBalance: {

      _ShowTotalBalancesScreen();
      _GoBackToTransactionsMenue();
      break;
    }

    case enTransactionsMenueOptions::eShowMainMenue: {
      break;
    }
    }
  }

public:
  static void ShowTransactionsMenue() {

    if (!CheckAccessRights(clsBankUsers::enPermissions::pTranactions)) {
      return;
    }

    _DrawScreenHeader("\t  Transactions Screen");

    cout << setw(0) << left << ""
         << "===========================================\n";
    cout << setw(0) << left << ""
         << "\t\t  Transactions Menue\n";
    cout << setw(0) << left << ""
         << "===========================================\n";
    cout << setw(0) << left << ""
         << "\t[1] Deposit.\n";
    cout << setw(0) << left << ""
         << "\t[2] Withdraw.\n";
    cout << setw(0) << left << ""
         << "\t[3] Total Balances.\n";
    cout << setw(0) << left << ""
         << "\t[4] Main Menue.\n";
    cout << setw(0) << left << ""
         << "===========================================\n";

    _PerformTransactionsMenueOption(
        (enTransactionsMenueOptions)ReadTransactionsMenueOption());
  }
};
