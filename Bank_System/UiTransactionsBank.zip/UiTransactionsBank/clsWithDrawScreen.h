#pragma once

#include "/home/ww816613abdo/Ui/clsScreen.h"
#include "/home/ww816613abdo/LogicBankPorject/clsBankClient.h"
#include "/home/ww816613abdo/clsInputValidate.h"
#include <iostream>
#include <string>

class clsWithDrawScreen : protected clsScreen {

private:
  static void _PrintClient(clsBankClient Client) {
    cout << "\nClient Card:";
    cout << "\n___________________";
    cout << "\nFirstName   : " << Client.FirstName();
    cout << "\nLastName    : " << Client.LastName();
    cout << "\nFull Name   : " << Client.FullName();
    cout << "\nEmail       : " << Client.Email();
    cout << "\nPhone       : " << Client.Phone();
    cout << "\nAcc. Number : " << Client.AccountNumber();
    cout << "\nPassword    : " << Client.GetPinCode();
    cout << "\nBalance     : " << Client.GetAccountBalance();
    cout << "\n___________________\n";
  }

  static string _ReadAccountNumber() {
    string AccountNumber = "";
    cout << "\nPlease enter AccountNumber? ";
    cin >> AccountNumber;
    return AccountNumber;
  }

public:
  static void ShowWithDrawScreen() {
    _DrawScreenHeader("\t   WithDraw Screen");

    string AccountNumber = _ReadAccountNumber();

    while (!clsBankClient::IsClientExist(AccountNumber)) {
      cout << "\nClient with [" << AccountNumber << "] does not exist.\n";
      AccountNumber = _ReadAccountNumber();
    }

    clsBankClient Client = clsBankClient::Find(AccountNumber);
    _PrintClient(Client);

    double Amount = 0;

    cout << "\nPlease enter WithDraw amount? your Balance is :  ";
    Amount = clsInputValidate::ReadDblNumber();

    cout << "\nAre you sure you want to perform this transaction? ";
    char Answer = 'n';
    cin >> Answer;

    if (Answer == 'Y' || Answer == 'y') {
      if (Client.WithDraw(Amount)) {
        cout << "\nAmount Withdrew Successfully.\n";
        cout << "\nNew Balance Is: " << Client.GetAccountBalance();
      } else {
        cout << "\nCannot withdraw, Insuffecient Balance!\n";
        cout << "\nAmout to withdraw is: " << Amount;
        cout << "\nYour Balance is: " << Client.GetAccountBalance();
      }

    } else {
      cout << "\nOperation was cancelled.\n";
    }
  }
};
