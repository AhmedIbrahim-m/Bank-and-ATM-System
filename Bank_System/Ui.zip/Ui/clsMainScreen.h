#pragma once
#include "/home/ww816613abdo/UiInOut/Global.h"
#include "/home/ww816613abdo/UiTransactionsBank/clsTransactionMainScreen.h"
#include "/home/ww816613abdo/UiUsersBank/clsUsersMainScreen.h"
#include "/home/ww816613abdo/clsInputValidate.h"
#include "clsAddClientScreen.h"
#include "clsClientListScreen.h"
#include "clsDeleteClientScreen.h"
#include "clsFindClientScreen.h"
#include "clsScreen.h"
#include "clsUpdateClientScreen.h"
#include <cstdlib>
#include <iomanip>
#include <iostream>
using namespace std;

class clsMainScreen : protected clsScreen {

private:
  enum enMainMenueOptions {
    eListClients = 1,
    eAddNewClient = 2,
    eDeleteClient = 3,
    eUpdateClient = 4,
    eFindClient = 5,
    eShowTransactionsMenue = 6,
    eManageUsers = 7,
    eExit = 8
  };

  static short _ReadMainMenueOption() {
    cout << setw(0) << left << ""
         << "Choose what do you want to do? [1 to 8]? ";
    short Choice = clsInputValidate::ReadIntNumberBetween(
        1, 8, "Enter Number between 1 to 8? ");
    return Choice;
  }

  static void _GoBackToMainMenue() {
    cout << setw(0) << left << ""
         << "\n\tPress any key to go back to Main Menue...\n";
    cin.ignore();
    cin.get();
    cout << "\033[2J\033[1;1H";
    ShowMainMenue();
  }

  static void _ShowAllClientsScreen() {
    // cout << "\nClient List Screen Will be here...\n";
    clsClientListScreen::ShowClientsList();
  }

  static void _ShowAddNewClientsScreen() {
    clsAddClientScreen::ShowAddNewClient();
  }

  static void _ShowDeleteClientScreen() {
    clsDeleteClientScreen::ShowDeleteClient();
  }

  static void _ShowUpdateClientScreen() {
    clsUpdateClientScreen::ShowUpdateClient();
  }

  static void _ShowFindClientScreen() {
    clsFindClientScreen::ShowFindClientScreen();
  }

  static void _ShowTransactionsMenue() {
    clsTransactionMainScreen::ShowTransactionsMenue();
  }

  static void _ShowManageUsersMenue() {
    clsManageUsersScreen::ShowManageUsersMenue();
  }

  static void _LogOut() { CurrentUser = clsBankUsers::Find("", ""); }

  static void _PerformMainMenueOption(enMainMenueOptions MainMenueOption) {

    switch (MainMenueOption) {

    case enMainMenueOptions::eListClients: {
      cout << "\033[2J\033[1;1H";
      _ShowAllClientsScreen();
      _GoBackToMainMenue();
      break;
    }

    case enMainMenueOptions::eAddNewClient: {

      cout << "\033[2J\033[1;1H";
      _ShowAddNewClientsScreen();
      _GoBackToMainMenue();
      break;
    }

    case enMainMenueOptions::eDeleteClient: {

      cout << "\033[2J\033[1;1H";
      _ShowDeleteClientScreen();
      _GoBackToMainMenue();
      break;
    }

    case enMainMenueOptions::eUpdateClient: {

      cout << "\033[2J\033[1;1H";
      _ShowUpdateClientScreen();
      _GoBackToMainMenue();
      break;
    }

    case enMainMenueOptions::eFindClient: {

      cout << "\033[2J\033[1;1H";
      _ShowFindClientScreen();
      _GoBackToMainMenue();
      break;
    }

    case enMainMenueOptions::eShowTransactionsMenue: {

      cout << "\033[2J\033[1;1H";
      _ShowTransactionsMenue();
      _GoBackToMainMenue();
      break;
    }

    case enMainMenueOptions::eManageUsers: {

      cout << "\033[2J\033[1;1H";
      _ShowManageUsersMenue();
      _GoBackToMainMenue();
      break;
    }

    case enMainMenueOptions::eExit: {

      cout << "\033[2J\033[1;1H";
      _LogOut();
      break;
    }
    };
  }

public:
  static void ShowMainMenue() {

    cout << "\033[2J\033[1;1H";
    _DrawScreenHeader("\t\tMain Screen");

    cout << setw(0) << left << ""
         << "===========================================\n";
    cout << setw(0) << left << ""
         << "\t\t\tMain Menue\n";
    cout << setw(0) << left << ""
         << "===========================================\n";
    cout << setw(0) << left << ""
         << "\t[1] Show Client List.\n";
    cout << setw(0) << left << ""
         << "\t[2] Add New Client.\n";
    cout << setw(0) << left << ""
         << "\t[3] Delete Client.\n";
    cout << setw(0) << left << ""
         << "\t[4] Update Client Info.\n";
    cout << setw(0) << left << ""
         << "\t[5] Find Client.\n";
    cout << setw(0) << left << ""
         << "\t[6] Transactions.\n";
    cout << setw(0) << left << ""
         << "\t[7] Manage Users.\n";
    cout << setw(0) << left << ""
         << "\t[8] Logout.\n";
    cout << setw(0) << left << ""
         << "===========================================\n";

    []() { cout << "Abdelrahman" << endl; };

    _PerformMainMenueOption((enMainMenueOptions)_ReadMainMenueOption());
  }
};