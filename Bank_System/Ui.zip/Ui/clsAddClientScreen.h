#pragma once
#include "/home/ww816613abdo/LogicBankPorject/clsBankClient.h"
#include "/home/ww816613abdo/clsInputValidate.h"
#include "clsScreen.h"
#include <cstdio>
#include <iostream>
#include <string>
using namespace std;

class clsAddClientScreen : clsScreen {

  static void _ReadClientInfo(clsBankClient &Client) {

    Client.setFirstName(clsInputValidate::ReadString("\nEnter FirstName: "));

    Client.setLastName(clsInputValidate::ReadString("\nEnter LastName: "));

    Client.setEmail(clsInputValidate::ReadString("\nEnter Email: "));

    Client.setPhone(clsInputValidate::ReadString("\nEnter Phone: "));

    Client.SetPinCode(clsInputValidate::ReadString("\nEnter PinCode: "));

    Client.SetAccountBalance(
        clsInputValidate::ReadDblNumber("\nEnter Account Balance: "));
  }

  static void _Print(clsBankClient Client) {
    cout << "\nClient Card:";
    cout << "\n___________________";
    cout << "\nFirstName   : " << Client.FirstName();
    cout << "\nLastName    : " << Client.LastName();
    cout << "\nFull Name   : " << Client.FullName();
    cout << "\nEmail       : " << Client.Email();
    cout << "\nPhone       : " << Client.Phone();
    cout << "\nAcc. Number : " << Client.AccountNumber();
    cout << "\nPassword    : " << Client.GetPinCode();
    cout << "\nBalance     : " << Client.GetAccountBalance();
    cout << "\n___________________\n";
  }

public:
  static void ShowAddNewClient() {

    if (!CheckAccessRights(clsBankUsers::enPermissions::pAddNewClient)) {
      return; 
    }

    string AccountNumber = "";

    string Massage = "Anter the Account Number?";

    _DrawScreenHeader("Add New Client Screen");

    AccountNumber = clsInputValidate::ReadString(Massage);

    while (clsBankClient::IsClientExist(AccountNumber)) {
      cout << "Account Number is Already Used, choose another one" << endl;
      AccountNumber = clsInputValidate::ReadString(Massage);
    }

    clsBankClient Client = clsBankClient::GetAddNewClientObject(AccountNumber);

    _ReadClientInfo(Client);
    clsBankClient::enSaveResults SaveResult;

    SaveResult = Client.Save();

    switch (SaveResult) {
    case clsBankClient::enSaveResults::svSucceeded: {
      cout << "\nAccount Addeded Successfully :-)\n";
      _Print(Client);
      break;
    }
    case clsBankClient::enSaveResults::svFaildEmptyObject: {
      cout << "\nError account was not saved because it's Empty";
      break;
    }
    case clsBankClient::enSaveResults::svFaildAccountNumberExists: {
      cout << "\nError account was not saved because account number is used!\n";
      break;
    }
    }
  }
};
