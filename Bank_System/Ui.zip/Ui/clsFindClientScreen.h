#pragma once
#include "/home/ww816613abdo/LogicBankPorject/clsBankClient.h"
#include "/home/ww816613abdo/clsInputValidate.h"
#include "clsScreen.h"
#include <iostream>
using namespace std;

class clsFindClientScreen : clsScreen {

private:
  static void _Print(clsBankClient Client) {
    cout << "\nClient Card:";
    cout << "\n___________________";
    cout << "\nFirstName   : " << Client.FirstName();
    cout << "\nLastName    : " << Client.LastName();
    cout << "\nFull Name   : " << Client.FullName();
    cout << "\nEmail       : " << Client.Email();
    cout << "\nPhone       : " << Client.Phone();
    cout << "\nAcc. Number : " << Client.AccountNumber();
    cout << "\nPassword    : " << Client.GetPinCode();
    cout << "\nBalance     : " << Client.GetAccountBalance();
    cout << "\n___________________\n";
  }

public:
  static void ShowFindClientScreen() {

    if (!CheckAccessRights(clsBankUsers::enPermissions::pFindClient)) {
      return;
    }

    _DrawScreenHeader("\n Find Client Screen");

    string AccountNumber = "";

    AccountNumber = clsInputValidate::ReadString("enter Account Number");

    while (!clsBankClient::IsClientExist(AccountNumber)) {

      cout << "Account number is not found, choose another one: " << endl;
      AccountNumber = clsInputValidate::ReadString("");
    }

    clsBankClient Client = clsBankClient::Find(AccountNumber);

    if (!Client.IsEmpty()) {
      cout << "\nClient Found :-)\n";
      _Print(Client);
    } else {
      cout << "\nClient Was not Found :-(\n";
    }
  }
};
