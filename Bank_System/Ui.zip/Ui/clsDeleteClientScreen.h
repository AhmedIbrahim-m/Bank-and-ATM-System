#pragma once
#include "/home/ww816613abdo/LogicBankPorject/clsBankClient.h"
#include "/home/ww816613abdo/clsInputValidate.h"
#include "clsScreen.h"
#include <iostream>

using namespace std;

class clsDeleteClientScreen : public clsScreen {

private:
  static void _Print(clsBankClient Client) {
    cout << "\nClient Card:";
    cout << "\n___________________";
    cout << "\nFirstName   : " << Client.FirstName();
    cout << "\nLastName    : " << Client.LastName();
    cout << "\nFull Name   : " << Client.FullName();
    cout << "\nEmail       : " << Client.Email();
    cout << "\nPhone       : " << Client.Phone();
    cout << "\nAcc. Number : " << Client.AccountNumber();
    cout << "\nPassword    : " << Client.GetPinCode();
    cout << "\nBalance     : " << Client.GetAccountBalance();
    cout << "\n___________________\n";
  }

public:
  static void ShowDeleteClient() {

    if (!CheckAccessRights(clsBankUsers::enPermissions::pDeleteClient)) {
      return;
    }

    string AccountNumber = "";

    _DrawScreenHeader("\n Delete Client Screen");

    AccountNumber = clsInputValidate::ReadString("enter Account Number");

    while (!clsBankClient::IsClientExist(AccountNumber)) {

      cout << "Account number is not found, choose another one: " << endl;
      AccountNumber = clsInputValidate::ReadString();
    }

    clsBankClient Client = clsBankClient::Find(AccountNumber);
    _Print(Client);

    cout << "Are you sure you want to delete this client [y/n] ?" << endl;

    char Answer = 'n';
    cin >> Answer;

    if (Answer == 'y' || Answer == 'Y') {

      if (Client.Delete()) {

        cout << "Client deleted successfully" << endl;

        _Print(Client);

      } else {

        cout << "Error Client was not deleted" << endl;
      }
    }
  }
};