#pragma once
#include "/home/ww816613abdo/UiInOut/Global.h"
#include "/home/ww816613abdo/clsDate.h"
#include <iomanip>
#include <iostream>
using namespace std;

class clsScreen {
protected:
  static void _DrawScreenHeader(string Title, string SubTitle = "") {
    cout << setw(20) << left << "______________________________________";
    cout << "\n\n  " << Title;
    if (SubTitle != "") {
      cout << setw(20) << "" << "\n  " << SubTitle;
    }
    cout << setw(20) << left << "\n______________________________________\n\n";

    
    cout << setw(0) << "" << "User : " << CurrentUser.GetUserName() << endl;
    cout << setw(0) << "" << "Date : "<<clsDate::PrintDateNow()<<endl;
  }

  static bool CheckAccessRights(clsBankUsers::enPermissions Permission) {

    if (!CurrentUser.CheckAccessPermission(Permission)) {
      _DrawScreenHeader("Access Denied! Contact your Admin.");
      return false;
    } else {
      return true;
    }
  }
};