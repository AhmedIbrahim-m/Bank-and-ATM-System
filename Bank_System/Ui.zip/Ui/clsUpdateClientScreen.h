#pragma once
#include "/home/ww816613abdo/LogicBankPorject/clsBankClient.h"
#include "/home/ww816613abdo/clsInputValidate.h"
#include "clsScreen.h"
#include <iostream>
#include <string>

using namespace std;

class clsUpdateClientScreen : clsScreen {

private:
  static string _InvalidInput(string Input, string Equal, bool Mode = true) {

    if (Mode && (Input == "")) {

      return Equal;
    }

    return Input;
  }

  static void _ReadClientInfo(clsBankClient &Client) {

    Client.setFirstName(
        _InvalidInput(clsInputValidate::ReadStringNotws("\nEnter FirstName: "),
                      Client.FirstName()));

    Client.setLastName(
        _InvalidInput(clsInputValidate::ReadStringNotws("\nEnter LastName: "),
                      Client.LastName()));

    Client.setEmail(_InvalidInput(
        clsInputValidate::ReadStringNotws("\nEnter Email: "), Client.Email()));

    Client.setPhone(_InvalidInput(
        clsInputValidate::ReadStringNotws("\nEnter Phone: "), Client.Phone()));

    Client.SetPinCode(
        _InvalidInput(clsInputValidate::ReadStringNotws("\nEnter PinCode: "),
                      Client.GetPinCode()));

    Client.SetAccountBalance(
        clsInputValidate::ReadDblNumber("\nEnter Account Balance: "));
  }

  static void _Print(clsBankClient Client) {
    cout << "\nClient Card:";
    cout << "\n___________________";
    cout << "\nFirstName   : " << Client.FirstName();
    cout << "\nLastName    : " << Client.LastName();
    cout << "\nFull Name   : " << Client.FullName();
    cout << "\nEmail       : " << Client.Email();
    cout << "\nPhone       : " << Client.Phone();
    cout << "\nAcc. Number : " << Client.AccountNumber();
    cout << "\nPassword    : " << Client.GetPinCode();
    cout << "\nBalance     : " << Client.GetAccountBalance();
    cout << "\n___________________\n";
  }

public:
  static void ShowUpdateClient() {

    if (!CheckAccessRights(clsBankUsers::enPermissions::pUpdateClients)) {
      return;
    }

    string AccountNumber = "";

    cout << "\nPlease Enter client Account Number: ";
    AccountNumber = clsInputValidate::ReadString("");

    while (!clsBankClient::IsClientExist(AccountNumber)) {
      cout << "\nAccount number is not found, choose another one: ";
      AccountNumber = clsInputValidate::ReadString();
    }

    clsBankClient Client = clsBankClient::Find(AccountNumber);
    _Print(Client);

    cout << "\n\nUpdate Client Info:";
    cout << "\n____________________\n";

    _ReadClientInfo(Client);

    clsBankClient::enSaveResults SaveResult;

    SaveResult = Client.Save();

    switch (SaveResult) {
    case clsBankClient::enSaveResults::svSucceeded: {
      cout << "\nAccount Updated Successfully :-)\n";
      _Print(Client);
      break;
    }
    case clsBankClient::enSaveResults::svFaildEmptyObject: {
      cout << "\nError account was not saved because it's Empty";
      break;
    }
    }
  }
};
